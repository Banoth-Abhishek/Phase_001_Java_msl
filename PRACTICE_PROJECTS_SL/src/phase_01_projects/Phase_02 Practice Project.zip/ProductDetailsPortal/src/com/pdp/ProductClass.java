package com.pdp;

import java.util.*;

public class ProductClass {
	
	private int id;
	private String name;
	private float price;
	private String warranty;
	
	public ProductClass(int id,String name, float price, String warranty){
		this.id=id;
		this.name=name;
		this.price=price;
		this.warranty=warranty;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	
	public ArrayList<ProductClass> getProductDetails(){
		ArrayList<ProductClass> productList = new ArrayList<ProductClass>();
		productList.add(new ProductClass(id,name,price,warranty));
		/*for(ProductClass s : productList){
			System.out.println("ID, Name, Price and Warranty of the product are: ");
			System.out.println(s.id+" "+s.name+" "+s.price+" "+s.warranty);
		}*/
		return productList;
	}
	
	

}

