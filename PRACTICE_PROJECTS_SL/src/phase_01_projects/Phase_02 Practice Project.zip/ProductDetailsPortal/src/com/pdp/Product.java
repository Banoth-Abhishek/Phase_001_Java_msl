package com.pdp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Product
 */
@WebServlet("/Product")
public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Product() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
    	out.println("<html>");
    	out.println("<body>");
    	try{
    		int id = Integer.parseInt(request.getParameter("id"));
    		String name = request.getParameter("name");
    		float price = Float.parseFloat(request.getParameter("price"));
    		String warranty = request.getParameter("warranty");
    		
    		ProductClass product1 = new ProductClass(id,name,price,warranty);
    		
    		HttpSession session = request.getSession();
    		session.setAttribute("data", product1);
    		request.setAttribute("data", product1.getProductDetails());
    		RequestDispatcher rd = request.getRequestDispatcher("PDP02jsp.jsp");
    		rd.forward(request,response);
    		
    	}
    	
    	catch(NumberFormatException e){
    		out.println(e);
    	}
    	catch(Exception e){
    		out.println(e);
    	}
    	
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

}
