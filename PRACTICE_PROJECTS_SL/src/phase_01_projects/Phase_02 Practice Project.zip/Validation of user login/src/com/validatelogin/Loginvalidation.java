package com.validatelogin;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Loginvalidation
 */
@WebServlet("/Loginvalidation")
public class Loginvalidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String Username = request.getParameter("username");
		String Password = request.getParameter("password");
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		if(Username.equals("Abhishek02@gmail.com") && Password.equals("Abhishek")){
			
			out.println("<h3>Your Details are Validated</h3>");
			out.write("<p><a  href=\"userlogin.html\">Logout</p></a>");

		}
		else{
			out.println("<h3>Your Details are Invalid!</h3>");
		}
	}

}
