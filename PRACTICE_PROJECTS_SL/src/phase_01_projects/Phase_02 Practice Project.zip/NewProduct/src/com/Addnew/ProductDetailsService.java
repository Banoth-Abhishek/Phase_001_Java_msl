package com.Addnew;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.Addnew.Product;
import com.Addnew.HibernateUtil;


public class ProductDetailsService {
	
	public void addProduct(Product product){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction trans = session.getTransaction();
		
		try{
			
			trans.begin();
			session.save(product);
			
			trans.commit();
		}
		
		catch(Exception e){
			if(trans!=null){
				trans.rollback();
			}
			e.printStackTrace();
		}
		finally{
			if(session!=null){
				session.close();
			}
		}
		
	}
	
	public List<Product> getproducts(){
		List<Product> products=null;
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction trans = session.getTransaction();
		
		try{
			trans.begin();
			products = session.createQuery("from Product").list();
			
			trans.commit();	
		}
		
		catch(Exception e){
			if(trans!=null){
				trans.rollback();
			}
			e.printStackTrace();
		}
		finally{
			if(session!=null){
				session.close();
			}
		}
		return products;
	}

}
