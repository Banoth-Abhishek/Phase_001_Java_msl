package com.Addnew;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Addnew.Product;

import com.Addnew.ProductDetailsService;


/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductS")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ProductDetailsService productdetailsservice;
	
	public void init() throws ServletException{
		super init();
		this.productdetailsservice = new ProductDetailsService();
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   /* public ProductServlet() {
       super();
        // TODO Auto-generated constructor stub
    }*/

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		List<Product>products = this.productdetailsservice.getproducts();
		
		request.setAttribute("product", products);
		
		RequestDispatcher rd = request.getRequestDispatcher("/Viewproducts.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		int productid = Integer.parseInt(request.getParameter("productid"));
		String productname = new request.getParameter("productname");
		float productprice = Float.parseFloat(request.getParameter("productprice"));
		
		Product product = new Product(productid,productname,productprice);
		
		this.productdetailsservice.addProduct(product);
		
        List<Product> products = this.productdetailsservice.getproducts();
		
		request.setAttribute("products", products);
		
		RequestDispatcher rd = request.getRequestDispatcher("/viewproducts.jsp");
		rd.forward(request, response);

		
		
	}

}
