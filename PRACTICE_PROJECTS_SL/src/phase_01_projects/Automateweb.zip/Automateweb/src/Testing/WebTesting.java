package Testing;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;


public class WebTesting {

	@Test(priority = 1, groups = {"webTests", "smokeTests"})
	public void registrationForm() throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C://Users//ABHISHEK BANOTH//Documents//JAVA MPHASIS//Phase-05//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		System.out.println("opening Registration Form");
		 driver.get("https://nxtgenaiacademy.com/demo-site/");
		Thread.sleep(1000);
		
		 
		 driver.findElement(By.id("vfb-5")).sendKeys("Abhishek");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-7")).sendKeys("Banoth");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-8-1")).click();
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-13-address")).sendKeys("Mamidiguda");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-13-address-2")).sendKeys("B-228");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-13-city")).sendKeys("Mandamarri");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-13-state")).sendKeys("Telangana");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-13-zip")).sendKeys("508654");
		 Thread.sleep(1500);
		 
		 Select drpCountry  =  new  Select(driver.findElement(By.id("vfb-13-country")));
		 drpCountry.selectByVisibleText("India");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-14")).sendKeys("abhishek@gmail.com");
		 Thread.sleep(1500);
		 
		 Select drpHour  =  new  Select(driver.findElement(By.id("vfb-16-hour")));
		 drpHour.selectByVisibleText("14");
		 Thread.sleep(1500);
		 
		 Select drpMin  =  new  Select(driver.findElement(By.id("vfb-16-min")));
		 drpMin.selectByVisibleText("30");
		 Thread.sleep(1500);
		 
		
		 
		 driver.findElement(By.id("vfb-19")).sendKeys("9774556635");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-20-2")).click();
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-23")).sendKeys("No queries");
		 Thread.sleep(1500);
		 
		 driver.findElement(By.id("vfb-3")).sendKeys("22");
		 Thread.sleep(1500);
		 
		 TakesScreenshot ts = (TakesScreenshot)driver;
		    File scr = ts.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\RF.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		 
		 driver.findElement(By.xpath("//input[@type='submit']")).click();
		 Thread.sleep(1500);
		 
		 TakesScreenshot ts2 = (TakesScreenshot)driver;
		    File scr2 = ts.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr2, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\RF2.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		 driver.quit();
		 System.out.println("You have Successfully Registered for Demo Class");	 
	}
	
	@Test(priority = 2,groups= {"webTestings"})
	public void login() throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C://Users//ABHISHEK BANOTH//Documents//JAVA MPHASIS//Phase-05//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		 
		 System.out.println("opening Login form");
		 driver.navigate().to("https://the-internet.herokuapp.com/login");
		 TakesScreenshot ts8 = (TakesScreenshot)driver;
		    File scr8 = ts8.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr8, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\Login.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		    Thread.sleep(1500);
		    
		    driver.findElement(By.id("username")).sendKeys("tomsmith");
		    TakesScreenshot ts9 = (TakesScreenshot)driver;
		    File scr9 = ts9.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr9, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\Login2.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		    Thread.sleep(1500);
		    
		    driver.findElement(By.name("password")).sendKeys("SuperSecretPassword!");
		    TakesScreenshot ts10 = (TakesScreenshot)driver;
		    File scr10 = ts10.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr10, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\Login3.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		    Thread.sleep(1500);
		    
		    driver.findElement(By.xpath("//button[@type='submit']")).click();
		    Thread.sleep(1500);
		    
		    TakesScreenshot ts11 = (TakesScreenshot)driver;
		    File scr11 = ts11.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr11, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\Login4.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		    System.out.println("Login Successfull");
		    driver.quit();
	}
	
	@Test(priority = 3,groups= {"webTestings"})
	public void addtoCart() throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C://Users//ABHISHEK BANOTH//Documents//JAVA MPHASIS//Phase-05//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		 driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		 
		 driver.navigate().to("https://www.amazon.in");
		 Thread.sleep(1000);
		 TakesScreenshot ts3 = (TakesScreenshot)driver;
		    File scr3 = ts3.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr3, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\ATC.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		 driver.findElement(By.id("twotabsearchtextbox")).sendKeys("pendrive");
		 Thread.sleep(1000);
		 TakesScreenshot ts4 = (TakesScreenshot)driver;
		    File scr4 = ts4.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr4, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\ATC2.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		 System.out.println("You have searched for a 'pendrive.'");
		 driver.findElement(By.id("nav-search-submit-button")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.linkText("Kingston")).click();
		 TakesScreenshot ts5 = (TakesScreenshot)driver;
		    File scr5 = ts5.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr5, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\ATC3.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		 System.out.println("The Selected brand is Kingston.");
		 Thread.sleep(1000);
		 driver.findElement(By.partialLinkText("Kingston DataTraveler 20 32GB USB Flash Drive (DT20/32GBIN, Black)")).click();
		 Thread.sleep(1000);
		 TakesScreenshot ts6 = (TakesScreenshot)driver;
		    File scr6 = ts6.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr6, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\ATC4.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
		 System.out.println("Your selected item is'Kingston DataTraveler 20 32GB USB Flash Drive (DT20/32GBIN, Black).'");
		 Set<String> ids = driver.getWindowHandles();
	        Iterator<String> it = ids.iterator();
	        String parentId = it.next();
	        String childId = it.next();
	        driver.switchTo().window(childId);
	        driver.findElement(By.id("add-to-cart-button")).click();
	        TakesScreenshot ts7 = (TakesScreenshot)driver;
		    File scr7 = ts7.getScreenshotAs(OutputType.FILE);
		    try {
	            FileUtils.copyFile(scr7, new File("C:\\Users\\ABHISHEK BANOTH\\Documents\\SL\\SS\\ATC5.png"));
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
	        Thread.sleep(1000);
	        System.out.println("Your item Successfully Add To Cart");
	        System.out.println("---------------------------------------");
	        System.out.println("---------------------------------------");
		 driver.quit();
	}
	
	

}
