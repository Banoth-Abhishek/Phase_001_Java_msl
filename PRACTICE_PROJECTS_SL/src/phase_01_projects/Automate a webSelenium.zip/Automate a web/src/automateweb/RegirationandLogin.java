package automateweb;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegirationandLogin {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C://Users//ABHISHEK BANOTH//Documents//JAVA MPHASIS//Phase-05//chromedriver.exe");
	    WebDriver driver = new ChromeDriver(); 
	    Thread.sleep(3000);
         
	    driver.manage().window().maximize();
	    System.out.println("Page is opened");
	    System.out.println("Starting Registration Test");
	    driver.get("https://accounts.lambdatest.com/register");
	    
	    
	    
	  WebElement name = driver.findElement(By.name("name"));
	  name.sendKeys("Abhishek");
	  Thread.sleep(1000);
	    
	    driver.findElement(By.name("email")).sendKeys("abhishek@gmail.com");
	    Thread.sleep(1000);
	    
	    driver.findElement(By.name("password")).sendKeys("Abhishek@123");
	    Thread.sleep(1000);
	    
	    driver.findElement(By.name("phone")).sendKeys("8974653125");
	    Thread.sleep(1000);
	    
	   WebElement checkbox = driver.findElement(By.xpath("//input[@type='checkbox']"));
	   checkbox.isSelected();
       Thread.sleep(1000);
    
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(1500);
	    
	    System.out.println("Directed to Login page");
	    

	    
	    
	    
	    
	    //Automated Login page
	    
	    driver.navigate().to("https://the-internet.herokuapp.com/login");
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("username")).sendKeys("tomsmith");
	    Thread.sleep(2000);
	    
	    driver.findElement(By.name("password")).sendKeys("SuperSecretPassword!");
	    Thread.sleep(2000);
	    
	    driver.findElement(By.xpath("//button[@type='submit']")).click();
	    Thread.sleep(2000);
	    
	    Thread.sleep(5000);
	    
	    System.out.println("Login Successfull");
	    driver.quit();
	    
	    
	    
	    
	    
	}

}
