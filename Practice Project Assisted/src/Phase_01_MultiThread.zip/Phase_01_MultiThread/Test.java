package PracticeAssisted;

import java.io.IOException;
import java.nio.file.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			Files.deleteIfExists(Paths.get("C://Users//ABHISHEK BANOTH//Documents//JAVA SL//testFile2.txt"));
		}
		
		catch(NoSuchFileException e){
			System.out.println("No such file/directory exist");
			
		}
        catch(DirectoryNotEmptyException e){
        	System.out.println("Directory is nor empty.");
        }
		catch(IOException e){
			System.out.println("Invalid permission.");
		}
		System.out.println("Deletion successful.");
	}

}
