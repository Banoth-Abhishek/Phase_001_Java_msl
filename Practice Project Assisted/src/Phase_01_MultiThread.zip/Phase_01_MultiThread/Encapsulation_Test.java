package PracticeAssisted;

  class Encapsulate{
	private String name;
	private int Roll;
	private int age;
	
	public String getName() {
		return name;
	}

	public void setName(String newname) {
		this.name = newname;
	}

	public int getRoll() {
		return Roll;
	}

	public void setRoll(int newroll) {
		Roll = newroll;
	}

	public void setAge(int newage) {
		this.age = newage;
	}

	public int getAge(){
		return age;
	}
}

public class Encapsulation_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulate obj = new Encapsulate();
		obj.setName("Harsha");
		obj.setRoll(04);
		obj.setAge(21);
		System.out.println("My Name: "+obj.getName());
		System.out.println("My Roll: "+obj.getRoll());
		System.out.println("My Age: "+obj.getAge());

	}

}
