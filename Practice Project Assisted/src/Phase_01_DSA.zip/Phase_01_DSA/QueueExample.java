package PRACTICE;
import java.util.*;


public class QueueExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<String> locationsQueue  = new LinkedList<>();
		locationsQueue.add("Patna");
		locationsQueue.add("Delhi");
		locationsQueue.add("Kolkata");
		locationsQueue.add("Noida");
		locationsQueue.add("Gurgaon");
		System.out.println("Queue is: "+locationsQueue);
		System.out.println("Head of Queue is: "+locationsQueue.peek());
		locationsQueue.remove();
		System.out.println("After removeing Head of Queue: "+locationsQueue);
		System.out.println("Size of Queue is: "+locationsQueue.size());

	}

}
